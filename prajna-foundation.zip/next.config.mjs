/** @type {import('next').NextConfig} */
const nextConfig = {
  eslint: {
    ignoreDuringBuilds: true,
  },
  typescript: {
    ignoreBuildErrors: true,
  },
  images: {
    domains: ['blob.v0.dev'], // Add any external image domains you're using
    unoptimized: true, // Only optimize in production
  },
  // Enable static exports if needed (for platforms like Netlify that prefer it)
  // output: 'export', // Uncomment this line only if deploying to a static hosting platform
  
  // Improve production performance
  swcMinify: true,
  
  // Configure redirects if needed
  async redirects() {
    return []
  },
  
  // Configure headers for security
  async headers() {
    return [
      {
        source: '/(.*)',
        headers: [
          {
            key: 'X-Content-Type-Options',
            value: 'nosniff',
          },
          {
            key: 'X-Frame-Options',
            value: 'DENY',
          },
          {
            key: 'X-XSS-Protection',
            value: '1; mode=block',
          },
        ],
      },
    ]
  },
}

export default nextConfig
