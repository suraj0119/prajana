import { EmbeddedForm } from "../contact/embedded-form"

export function ContactSection() {
  return <EmbeddedForm />
}
