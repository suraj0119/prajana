import { TeamMembers } from "./team-members"

export function OurTeam() {
  return <TeamMembers />
}
